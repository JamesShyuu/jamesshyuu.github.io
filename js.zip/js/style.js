window.sr = ScrollReveal({ reset: true });
sr.reveal('.poster1-js',{ duration:1000,origin: 'bottom',scale:0.5});
sr.reveal('.poster1-js-resetoff',{ duration:1000,origin: 'bottom',scale:0.5,reset:false});
sr.reveal('.poster1-js-text',{ duration:1000,origin: 'left',delay:500,scale:0.5});
sr.reveal('.va-js-box', { duration: 500}, 50);
sr.reveal('.va-js-box1', { duration: 500}, 50);
sr.reveal('.va-js-box2', { duration: 500}, 50);
sr.reveal('.poster1-js-text-resetoff',{ duration:1000,origin: 'left',delay:500,scale:0.5,reset:false});